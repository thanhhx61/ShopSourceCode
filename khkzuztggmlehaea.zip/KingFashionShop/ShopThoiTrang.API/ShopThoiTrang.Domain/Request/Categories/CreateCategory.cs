﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShopThoiTrang.Domain.Request.Categories
{
    public class CreateCategory
    {
        public string CategoryName { get; set; }
    }
}
