﻿using KingFashion.Commons;
using KingFashion.Helpers;
using KingFashion.Models;
using KingFashion.Models.CategoryDetail;
using KingFashion.Models.Categorys;
using KingFashion.Models.Products;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KingFashion.Controllers
{
    public class ShopController : Controller
    {
        private readonly ILogger<ShopController> _logger;
        public ShopController(ILogger<ShopController> logger)
        {
            _logger = logger;
        }
        //[Route("")]
        //[Route("/Shop/ViewShop")]
        public async Task<IActionResult> Index()
        {
            ShopAll cateloryAll = new ShopAll();
            cateloryAll.ListCategories =  await ApiHelper.HttpGet<List<CategoriesView>>($@"{Common.ApiUrl}Category");
            cateloryAll.ListCategoryView = await ApiHelper.HttpGet<List<CategoryView>>(@$"{Common.ApiUrl}CategoryDetails");
            cateloryAll.ListViewProduct = await ApiHelper.HttpGet<List<ViewProduct>>($@"{Common.ApiUrl}Product");
            return View(cateloryAll);
        }
        [HttpPost]
        [Route("/Shop/Index/{productId:int}")]
        public async Task<IActionResult> Index(int productId)
        {
            ShopAll cateloryAll = new ShopAll();
            cateloryAll.ListCategories =  await ApiHelper.HttpGet<List<CategoriesView>>($@"{Common.ApiUrl}Category");
            cateloryAll.ListCategoryView = await ApiHelper.HttpGet<List<CategoryView>>($@"{Common.ApiUrl}CategoryDetails");
            cateloryAll.ListViewProduct = await ApiHelper.HttpGet<List<ViewProduct>>($@"{Common.ApiUrl}Product");
            cateloryAll.IdProduct = productId;
            return View(cateloryAll);
        }

        [HttpGet]
        [Route("/Shop/Get/{id}")]
        public IActionResult Get(int id)
        {
            var data = ApiHelper.HttpGet<ViewProduct>(@$"{Common.ApiUrl}Product/{id}");
            return Ok(data);
        }
        public async Task<IActionResult> ShoppingCart()
        {
            ShopAll cateloryAll = new ShopAll();
            cateloryAll.ListCategories = await ApiHelper.HttpGet<List<CategoriesView>>(@$"{Common.ApiUrl}Category");
            cateloryAll.ListCategoryView = await ApiHelper.HttpGet<List<CategoryView>>($@"{Common.ApiUrl}CategoryDetails");
            cateloryAll.ListViewProduct = await ApiHelper.HttpGet<List<ViewProduct>>($@"{Common.ApiUrl}Product");
            return View(cateloryAll);

        }

        public async Task<IActionResult> ViewShop()
        {
            ShopAll cateloryAll = new ShopAll();
            cateloryAll.ListCategories =  await ApiHelper.HttpGet<List<CategoriesView>>($@"{Common.ApiUrl}Category");
            cateloryAll.ListCategoryView = await ApiHelper.HttpGet<List<CategoryView>>($@"{Common.ApiUrl}CategoryDetails");
            cateloryAll.ListViewProduct = await ApiHelper.HttpGet<List<ViewProduct>>($@"{Common.ApiUrl}Product");
            return View(cateloryAll);

        }
        public async Task<IActionResult> Contact()
        {
            ShopAll cateloryAll = new ShopAll();
            cateloryAll.ListCategories = await ApiHelper.HttpGet<List<CategoriesView>>(@$"{Common.ApiUrl}Category");
            cateloryAll.ListCategoryView = await ApiHelper.HttpGet<List<CategoryView>>($@"{Common.ApiUrl}CategoryDetails");
            cateloryAll.ListViewProduct =  await ApiHelper.HttpGet<List<ViewProduct>>($@"{Common.ApiUrl}Product");
            return View(cateloryAll);

        }
    }
}
