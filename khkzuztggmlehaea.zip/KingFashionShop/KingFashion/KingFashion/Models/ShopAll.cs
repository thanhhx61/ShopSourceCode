﻿using KingFashion.Models.CategoryDetail;
using KingFashion.Models.Categorys;
using KingFashion.Models.Products;
using System;
using System.Collections.Generic;


namespace KingFashion.Models
{
    public class ShopAll
    {
       public  List<CategoryView> ListCategoryView { get; set; }

       public List<CategoriesView> ListCategories { get; set; }

        public List<ViewProduct> ListViewProduct { get; set; }

        public int IdProduct { get; set; }
    }
}
