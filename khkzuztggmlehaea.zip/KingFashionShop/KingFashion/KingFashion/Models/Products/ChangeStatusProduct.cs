﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KingFashion.Models.Products
{
    public class ChangeStatusProduct
    {
        public int ProductId { get; set; }
        public bool Status { get; set; }
    }
}
