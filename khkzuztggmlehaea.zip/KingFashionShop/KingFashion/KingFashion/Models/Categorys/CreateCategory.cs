﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KingFashion.Models.Categorys
{
    public class CreateCategory
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }
}
