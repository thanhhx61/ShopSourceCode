﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KingFashion.Commons
{
    public static class Common
    {
        public static string ApiUrl = "https://localhost:44315/api/";
    }
}
